
package com.example.microblog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroblogApplication {
    public static void main(String[] args) {
        SpringApplication.run(MicroblogApplication.class, args);
    }
}
